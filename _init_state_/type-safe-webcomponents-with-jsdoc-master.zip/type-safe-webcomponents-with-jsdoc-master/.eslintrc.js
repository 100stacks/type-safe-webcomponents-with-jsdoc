module.exports = {
  extends: ['@open-wc/eslint-config', 'eslint-config-prettier'],
};
