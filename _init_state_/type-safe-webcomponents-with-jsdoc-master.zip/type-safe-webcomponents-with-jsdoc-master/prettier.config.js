module.exports = require('@open-wc/prettier-config');
